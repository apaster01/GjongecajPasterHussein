/* ========================================
 *
 * The following firmware was developed by Cypress Semiconductor
 * This work is licensed under a Creative Commons Attribution 3.0 Unported License.
 * 
 * http://creativecommons.org/licenses/by/3.0/deed.en_US
 * 
 * You are free to:
 * -To Share — to copy, distribute and transmit the work 
 * -To Remix — to adapt the work 
 * -To make commercial use of the work
 *
 * ========================================
 */
 
/* CY8CKIT-042 PSoC 4 Flash Write Demo
 * By MAXK
 * Version **
 * Updated 5/17/2013
 *
 * Demonstrates storing data in flash and retrieving it later. Reserves space in
 * flash so that it does not overwrite other data allocated by the linker.
 * 
 * Hold button SW2 to scroll through colors. When you release the button, 
 * the color will stop changing, and will be written into flash. Upon power 
 * cycle or reset, the value will be restored and the color will be the same.
 *
 */
 
#include <device.h>
#include <LED_RGB.h>

/* Flash constants */
#define FLASH_ROW_SIZE_BYTES            128
#define FLASH_ALIGNED __attribute__ ((aligned (FLASH_ROW_SIZE_BYTES)))

/* Flash data array */
static const uint8 FLASH_ALIGNED flashRowDataFLASH[FLASH_ROW_SIZE_BYTES]={0};

/* Flash data write constants */
#define FLASH_DATA_BASE_ADDRESS_BYTE    (uint32) (&flashRowDataFLASH)
#define FLASH_DATA_BASE_ADDRESS_ROW     FLASH_DATA_BASE_ADDRESS_BYTE / FLASH_ROW_SIZE_BYTES

//volatile reset(uint16 prevColor)
//{
//    uint16 color;
//    uint8 flashWriteResult;
 //   uint8 FlashRowDataSRAM[128] = {0};
 //   if (!Pin_SW1_Read() == 0)   //ADAM Read"()" and == 0 ---> == 1
 //   {
 //       color = prevColor; 
        //write the new prevColor to flash so it will remember what the previous color was
 //   }
    
//}

int main()
{
    /* Variable declarations */
    uint16 color;
    uint16 prevColor; //ADAM EDITED
    uint8 flashWriteResult; //ADAM UINT8-->UINT16
    uint8 flashRowDataSRAM[128] = {0}; //ADAM UINT8-->UINT16

    /* Start LED_RGB module */
    LED_RGB_Start();

    /* Read the first two bytes out of the flash array */
    flashRowDataSRAM[0] = flashRowDataFLASH[0];
    flashRowDataSRAM[1] = flashRowDataFLASH[1];
    
    /* Reconstruct the color using the two bytes from flash */
    color = (flashRowDataSRAM[0]<<8) + flashRowDataSRAM[1];
    
    /* Initial LED color write */
    LED_RGB_SetColorCircle(prevColor); //ADAM EDITED (color)--->(prevColor)

    for(;;)
    {
        /* Scroll through colors if SW2 is pressed */
        if(!Pin_SW2_Read())
        {
            /* Scroll through colors until the button is released */
            while(!Pin_SW2_Read())
            {
                /* Scroll through the color wheel once every 5 seconds */
                color += 65535/5/1000;
                LED_RGB_SetColorCircle(color);
                CyDelay(1);
            }
            
            /* Configure the Flash Writes for the current clock frequency */
            CySysFlashSetWaitCycles(48);
            
            /* Populate the SRAM array with the two bytes of the current hue */
            flashRowDataSRAM[0] = color>>8;
            flashRowDataSRAM[1] = color&0x00ff;
            
            /* Write the SRAM array into flash */
            flashWriteResult = CySysFlashWriteRow(FLASH_DATA_BASE_ADDRESS_ROW, flashRowDataSRAM);
            
       //     reset(flashWriteResult);
            
        }
        
    }
}

/* [] END OF FILE */
